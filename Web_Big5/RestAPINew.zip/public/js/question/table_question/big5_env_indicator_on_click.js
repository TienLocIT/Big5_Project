function Big5EnvIndicatorOnClick(value){
    big5Envindicator.innerText=value;
    
}