
const big5EnvIndicatorFacetContent = document.querySelector(".big5EnvIndicator_content_facet");
const selectIndicatorOption = document.querySelector("#select_indicator_option");
const selectFacetOption = document.querySelector("#select_facet_option");
const selectKeywordOption = document.querySelector("#select_keyword_option");
const searchKeywords = document.querySelector("#search_keywords");
const big5EnvIndicatorKeywordContent = document.querySelector(".big5EnvIndicator_content_keyword");
const buttonChooseQuestion = document.querySelector("#user-modal__button-choose--question");
const buttonCancleChooseQuestion = document.querySelector("#user-modal__button-cancel-choose--question");
const loadingioBig5Modal=document.querySelector(".userchoose-modal__body .loadingiomodal")
const btnAddBig5IndicatorToList=document.querySelector("#btn_add_big5envindicator_to_list");
var big5EnvIndicatorList=[];
const big5EnvIndicatorContentList=document.querySelector(".big5EnvIndicator_content_list");