function newData() {
    question.value = "";
    big5Envindicator.value = "";
    levelOpenness.value = 2;
    levelNeuroticism.value = 2;
    levelExtraversion.value = 2;
    levelConscientious.value = 2;
    levelAgreeable.value = 2;
    pointHigh.value = 20;
    pointMedium.value = 15;
    pointLow.value = 10;
}
export default newData;