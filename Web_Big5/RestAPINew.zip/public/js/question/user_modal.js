usermodel.onclick = () => {
    usermodel.style.display = "none";
}
user__choooseOption_cancel.onclick = () => {
    bodySendModal.innerHTML = "";
    usermodel.style.display = "none";
}